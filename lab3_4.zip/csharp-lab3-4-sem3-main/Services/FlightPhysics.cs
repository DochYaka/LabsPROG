﻿using System;
using PilotTrainer.Models;

namespace PilotTrainer.Services
{
    public class FlightPhysics
    {
        private readonly Random random = new Random();

        public void Update(FlightData data)
        {
            double targetSpeed = data.Throttle * 600;
            data.Speed += (targetSpeed - data.Speed) * 0.05;

            double verticalSpeed = data.Speed * Math.Sin(data.Pitch * Math.PI / 180);

            data.Altitude += verticalSpeed * 0.2;

            if (data.Altitude < 0)
                data.Altitude = 0;

            double targetPitch =
                (data.Speed / 400 - 1) * 10 +
                (random.NextDouble() - 0.5) * 2;

            data.Pitch += (targetPitch - data.Pitch) * 0.02;
            data.Pitch = Clamp(data.Pitch, -30, 30);
        }


        private static double Clamp(double value, double min, double max)
        {
            if (value < min) return min;
            if (value > max) return max;
            return value;
        }
    }
}
