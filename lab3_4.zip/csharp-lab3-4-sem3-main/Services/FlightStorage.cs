﻿using System.IO;
using System.Text.Json;
using PilotTrainer.Models;

namespace PilotTrainer.Services
{
    public class FlightStorage
    {
        private const string FileName = "flight_data.json";

        public void Save(FlightData data)
        {
            string json = JsonSerializer.Serialize(
                data,
                new JsonSerializerOptions { WriteIndented = true }
            );
            File.WriteAllText(FileName, json);
        }

        public FlightData Load()
        {
            if (!File.Exists(FileName))
                return null;

            string json = File.ReadAllText(FileName);
            return JsonSerializer.Deserialize<FlightData>(json);
        }
    }
}
