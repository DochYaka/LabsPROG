﻿using PilotTrainer.Models;
using PilotTrainer.Services;

namespace PilotTrainer.Controllers
{
    public class FlightController
    {
        private readonly FlightPhysics physics = new FlightPhysics();

        private const double CRITICAL_ALTITUDE = 600;
        private const int MAX_DANGER_TICKS = 60;

        private int dangerTicks;

        public FlightData Data { get; } = new FlightData
        {
            Altitude = 500
        };

        public bool IsDefeat { get; private set; }

        public void Update()
        {
            if (IsDefeat)
                return;

            physics.Update(Data);
            UpdateDefeatState();
        }

        private void UpdateDefeatState()
        {
            if (Data.Altitude < CRITICAL_ALTITUDE)
            {
                dangerTicks++;

                if (dangerTicks >= MAX_DANGER_TICKS) { IsDefeat = true; }
            }
            else { dangerTicks = 0; }
        }

        public void Reset()
        {
            dangerTicks = 0;
            IsDefeat = false;

            Data.Throttle = 0;
            Data.Speed = 0;
            Data.Altitude = 1000;
            Data.Pitch = 0;
        }
    }
}
