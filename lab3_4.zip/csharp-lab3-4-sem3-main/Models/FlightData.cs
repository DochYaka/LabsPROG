﻿using System;

namespace PilotTrainer.Models
{
    public class FlightData
    {
        public double Throttle { get; set; }
        public double Speed { get; set; }
        public double Altitude { get; set; }
        public double Pitch { get; set; }
        public DateTime Timestamp { get; set; }
    }
}
