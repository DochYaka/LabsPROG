﻿using PilotTrainer.Controllers;
using PilotTrainer.Services;
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;

namespace PilotTrainer
{
    public partial class MainWindow : Window
    {
        private const double LEVER_HEIGHT = 40;
        private const double TRACK_HEIGHT = 180;
        private const double MAX_ALTITUDE = 800;
        private const double GROUND_Y = 600;
        private const double SKY_Y = 0;

        private bool isDragging;
        private Point dragStartPoint;
        private double dragStartTop;
        private bool defeatHandled;

        private readonly DispatcherTimer timer;
        private readonly FlightController controller = new FlightController();
        private readonly FlightStorage storage = new FlightStorage();

        public MainWindow()
        {
            InitializeComponent();

            timer = new DispatcherTimer
            {
                Interval = TimeSpan.FromMilliseconds(16)
            };
            timer.Tick += Timer_Tick;
            timer.Start();
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            controller.Update();
            UpdateDisplay();
            UpdatePitchIndicator();
            UpdatePlanePosition();

            if (controller.IsDefeat && !defeatHandled)
            {
                defeatHandled = true;

                MessageBox.Show(
                    "Самолёт разбился!\nИгра начнётся заново.",
                    "Поражение",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning
                );

                controller.Reset();
                Canvas.SetTop(ThrottleLever, TRACK_HEIGHT - LEVER_HEIGHT);

                defeatHandled = false;
            }
        }

        private void UpdatePlanePosition()
        {
            double altitude = controller.Data.Altitude;

            double t = altitude / MAX_ALTITUDE;
            t = Clamp(t, 0, 1);

            double y = GROUND_Y - t * (GROUND_Y - SKY_Y);

            Canvas.SetTop(MiniPlane, y);
        }

        private void UpdateDisplay()
        {
            SpeedText.Text = $"Скорость: {(int)controller.Data.Speed} км/ч";
            AltitudeText.Text = $"Высота: {(int)controller.Data.Altitude} м";
            ThrottleText.Text = $"{(int)(controller.Data.Throttle * 100)}%";
            PitchText.Text = $"Тангаж: {controller.Data.Pitch:F1}°";
        }

        private void UpdatePitchIndicator() //конвертация px в градусы. 
        {
            double pitch = controller.Data.Pitch;
            double offset = pitch * 3.33;

            //двигаем линию горизонта
            HorizonLine.Y1 = 100 + offset;
            HorizonLine.Y2 = 100 + offset;
            
            //отрисовка горизонта (небо и земли)
            SkyIndicator.Height = 100 + offset;
            GroundIndicator.Height = 100 - offset;
            Canvas.SetTop(GroundIndicator, 100 + offset);

            MiniPlane.RenderTransform = new TranslateTransform(0, -offset);
        }

        private void ThrottleLever_MouseDown(object sender, MouseButtonEventArgs e)
        {
            isDragging = true;
            dragStartPoint = e.GetPosition(ThrottleTrack);
            dragStartTop = Canvas.GetTop(ThrottleLever);
            ThrottleLever.CaptureMouse();
        }

        private void ThrottleLever_MouseMove(object sender, MouseEventArgs e)
        {
            if (!isDragging) return;

            Point p = e.GetPosition(ThrottleTrack);
            double delta = dragStartPoint.Y - p.Y;

            double newTop = Clamp(
                dragStartTop - delta,
                0,
                TRACK_HEIGHT - LEVER_HEIGHT);

            Canvas.SetTop(ThrottleLever, newTop);

            controller.Data.Throttle =
                1.0 - newTop / (TRACK_HEIGHT - LEVER_HEIGHT);
        }

        private static double Clamp(double v, double min, double max)
        {
            if (v < min) return min;
            if (v > max) return max;
            return v;
        }

        private void ThrottleLever_MouseUp(object sender, MouseButtonEventArgs e)
        {
            isDragging = false;
            ThrottleLever.ReleaseMouseCapture();
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            controller.Data.Timestamp = DateTime.Now;
            storage.Save(controller.Data);
            MessageBox.Show("Сохранено");
        }

        private void LoadButton_Click(object sender, RoutedEventArgs e)
        {
            var data = storage.Load();
            if (data == null) return;

            controller.Data.Throttle = data.Throttle;
            controller.Data.Speed = data.Speed;
            controller.Data.Altitude = data.Altitude;
            controller.Data.Pitch = data.Pitch;

            double top =
                (1.0 - data.Throttle) * (TRACK_HEIGHT - LEVER_HEIGHT);
            Canvas.SetTop(ThrottleLever, top);
        }

        private void ResetButton_Click(object sender, RoutedEventArgs e)
        {
            controller.Reset();
            Canvas.SetTop(ThrottleLever, TRACK_HEIGHT - LEVER_HEIGHT);
        }
    }
}
